package rhinotest;

import javax.script.Bindings;
import javax.script.Compilable;
import javax.script.CompiledScript;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import org.mozilla.javascript.Context;

public class RhinoTest {
	
	private static ScriptEngine getFastRhinoEngine(final boolean compile) {
		phobos_fast.script.javascript.RhinoScriptEngineFactory factory=new phobos_fast.script.javascript.RhinoScriptEngineFactory();

		final Context cx=Context.enter();
		cx.setOptimizationLevel(compile?9:-1);

		return factory.getScriptEngine();
	}
	
	public static ScriptEngine getNashornEngine() {
		final ScriptEngineManager manager=new ScriptEngineManager();
		return manager.getEngineByName("nashorn");
	}
	
	public static ScriptEngine getSlowRhinoEngine() {
		final ScriptEngineManager manager=new ScriptEngineManager();
		return manager.getEngineByName("rhino");
	}
	
	private static void setupBindings(final ScriptEngine engine) {
		final Bindings bindings=engine.getContext().getBindings(ScriptContext.ENGINE_SCOPE);
		
		bindings.put("connect",new ConnectDummyObj());		
	}
	
	private static String script="var s=\"text\"; var value=0; for (var i=0;i<10;i++) value+=connect.increment(i); s=connect.test(s); value;";
	
	public static void main(String[] args) throws Exception {
		System.out.print("waiting... (Enter for start)");
		System.in.read();
		System.out.println("started");
		
		final ScriptEngine engine;
		engine=getFastRhinoEngine(true);
		//engine=getSlowRhinoEngine();
		//engine=getNashornEngine();
		System.out.println(engine.getClass().getCanonicalName());
		setupBindings(engine);
		
		if (!(engine instanceof Compilable)) return;
		Compilable compilingEngine=(Compilable)engine;
		
		CompiledScript compiledScript=compilingEngine.compile(script);
		Object result=null;
		
		long startTime=System.currentTimeMillis();
		
		for (int i=0;i<1_000_000;i++) {
			result=compiledScript.eval();
		}
		
		System.out.println("Time: "+(System.currentTimeMillis()-startTime)+"ms");
		System.out.println("Script: "+result);
	}
	
	public static class ConnectDummyObj {
		public void sayHello() {
			System.out.println("Hello");
		}
		public int increment(final int value) {
			return value+1;
		}
		public String test(final String test) {
			return test;
		}
	}
}

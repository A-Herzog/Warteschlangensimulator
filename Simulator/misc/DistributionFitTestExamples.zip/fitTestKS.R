setwd("C:/Users/Alexa/Documents/Java/workspace-simulator/Sonstiges/DistributionFit")

xNorm<-scan(file="fitDataNormalR.txt");
xExp<-scan(file="fitDataExpR.txt");
xTwo<-scan(file="fitDataZweiPunkt.txt");

x=xNorm;
m=mean(x);
s=sd(x);

ks.test(x,"pexp",rate=1/m);
ks.test(x,"pnorm",mean=m,sd=s);